# Maddins Data Creation Tool

A python program for automated synthetic visual data creation.

### Features

* 
* Export your data collection to portable folder
* Supporting custom shadow and reflection catchers

### Requirements

* Blender (tested on 2.8 and 2.9)
* Python (>3.6)
  * imageio
  * PIL
  * numpy